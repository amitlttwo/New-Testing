import sys

from . import pghoard

sys.exit(pghoard.main())
