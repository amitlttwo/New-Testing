clients = {
    "statsd": ("pghoard.monitoring.statsd", "StatsClient"),
    "pushgateway": ("pghoard.monitoring.pushgateway", "PushgatewayClient"),
    "prometheus": ("pghoard.monitoring.prometheus", "PrometheusClient"),
}
